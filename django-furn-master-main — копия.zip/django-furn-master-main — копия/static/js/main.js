let email = document.getElementById('id_email')

email.placeholder  = "example@email.com"